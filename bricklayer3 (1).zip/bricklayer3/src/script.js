function gameOver() {
  clearInterval(interval);
  cancelAnimationFrame(animationFrameId);
  document.getElementById("gameOverSound").play();
  alert("Game Over! Your final score is: " + score);
  startNewGame();
}

function startNewGame() {
  initBoard();
  currentPiece = newPiece();
  nextPiece = newPiece();
  currentPieceX = Math.floor((COLS - currentPiece[0].length) / 2);
  currentPieceY = 0;
  score = 0;
  level = 1;
  updateScoreAndLevel();
  interval = setInterval(moveDown, 1000 / level);
  animate();
}

// Update the moveDown function
function moveDown() {
  if (!isPaused) { // Check if the game is not paused
    currentPieceY++;
    if (collision()) {
      currentPieceY--;
      placePiece();
      checkLines();
      currentPiece = nextPiece;
      nextPiece = newPiece();
      currentPieceX = Math.floor((COLS - currentPiece[0].length) / 2);
      currentPieceY = 0;
      if (collision()) {
        gameOver();
      }
    }
  }
}
